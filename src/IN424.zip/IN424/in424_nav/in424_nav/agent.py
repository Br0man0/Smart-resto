import rclpy
from rclpy.node import Node
from nav_msgs.msg import Odometry, OccupancyGrid
from sensor_msgs.msg import LaserScan
from geometry_msgs.msg import Twist
from rclpy.qos import qos_profile_sensor_data
from tf_transformations import euler_from_quaternion

import numpy as np

from .my_common import *    #common variables are stored here

from bresenham import bresenham

OCCUPIED_SPACE_VALUE = 100
FREE_SPACE_VALUE = 0
import random

class MonteCarloLocalization:
    def __init__(self, num_particles, map_size, robot_size):
        self.num_particles = num_particles
        self.map_size = map_size
        self.robot_size = robot_size
        self.particles = self.initialize_particles()
        self.weights = np.ones(num_particles) / num_particles
        self.resample_threshold = 0.5 * num_particles  # Pour le resampling adaptatif
        
    def initialize_particles(self):
        """ Initialiser les particules uniformément sur la carte """
        return [(random.uniform(-self.map_size[1]/2, self.map_size[1]/2),
                 random.uniform(-self.map_size[0]/2, self.map_size[0]/2),
                 random.uniform(-np.pi, np.pi))
                for _ in range(self.num_particles)]
    
    def motion_update(self, delta_x, delta_y, delta_yaw):
        """ Mettre à jour les particules selon le modèle de mouvement avec bruit """
        # Ajuster les paramètres de bruit selon les caractéristiques du robot
        noise_x = 0.05 * abs(delta_x) + 0.01
        noise_y = 0.05 * abs(delta_y) + 0.01
        noise_yaw = 0.1 * abs(delta_yaw) + 0.01
        
        self.particles = [(x + delta_x + np.random.normal(0, noise_x),
                           y + delta_y + np.random.normal(0, noise_y),
                           self.normalize_angle(yaw + delta_yaw + np.random.normal(0, noise_yaw)))
                          for (x, y, yaw) in self.particles]
    
    def normalize_angle(self, angle):
        """ Normaliser un angle entre -pi et pi """
        while angle > np.pi:
            angle -= 2.0 * np.pi
        while angle < -np.pi:
            angle += 2.0 * np.pi
        return angle
    
    def measurement_update(self, lidar_readings, current_map, robot_x, robot_y, robot_yaw, map_info):
        """ Mettre à jour les poids des particules avec les lectures LIDAR """
        angles = np.linspace(lidar_readings.angle_min, lidar_readings.angle_max, len(lidar_readings.ranges))
        
        for i, (px, py, pyaw) in enumerate(self.particles):
            # Calculer la probabilité que cette particule soit à la bonne position
            likelihood = 1.0
            
            # Échantillonner quelques rayons du LIDAR pour une comparaison efficace
            sampling_rate = 10  # Utiliser 1 rayon sur 10 
            for j in range(0, len(lidar_readings.ranges), sampling_rate):
                if lidar_readings.ranges[j] >= lidar_readings.range_max:
                    continue  # Ignorer les mesures hors de portée
                
                # Angle du rayon dans le référentiel global
                global_angle = pyaw + angles[j]
                
                # Point observé par le LIDAR depuis la position du robot
                observed_x = robot_x + lidar_readings.ranges[j] * np.cos(robot_yaw + angles[j])
                observed_y = robot_y + lidar_readings.ranges[j] * np.sin(robot_yaw + angles[j])
                
                # Point attendu si le robot était à la position de la particule
                expected_x = px + lidar_readings.ranges[j] * np.cos(global_angle)
                expected_y = py + lidar_readings.ranges[j] * np.sin(global_angle)
                
                # Convertir en indices de carte
                map_width = map_info.width
                map_height = map_info.height
                resolution = map_info.resolution
                origin_x = map_info.origin.position.x
                origin_y = map_info.origin.position.y
                
                # Indices de la carte pour le point observé
                obs_grid_x = int((observed_x - origin_x) / resolution)
                obs_grid_y = map_height - int((observed_y - origin_y) / resolution)
                
                # Indices de la carte pour le point attendu
                exp_grid_x = int((expected_x - origin_x) / resolution)
                exp_grid_y = map_height - int((expected_y - origin_y) / resolution)
                
                # Vérifier si les points sont dans les limites de la carte
                if (0 <= obs_grid_x < map_width and 0 <= obs_grid_y < map_height and
                    0 <= exp_grid_x < map_width and 0 <= exp_grid_y < map_height):
                    
                    # Valeur observée dans la carte
                    obs_value = current_map[obs_grid_y, obs_grid_x]
                    
                    # Valeur attendue dans la carte
                    exp_value = current_map[exp_grid_y, exp_grid_x]
                    
                    # Calculer la similitude entre les valeurs observées et attendues
                    if obs_value == OCCUPIED_SPACE_VALUE and exp_value == OCCUPIED_SPACE_VALUE:
                        # Les deux sont des obstacles - forte probabilité
                        ray_likelihood = 0.9
                    elif obs_value == FREE_SPACE_VALUE and exp_value == FREE_SPACE_VALUE:
                        # Les deux sont libres - bonne probabilité
                        ray_likelihood = 0.7
                    else:
                        # Différence - faible probabilité
                        ray_likelihood = 0.1
                    
                    likelihood *= ray_likelihood
            
            # Mettre à jour le poids de la particule
            self.weights[i] *= likelihood
        
        # Normaliser les poids
        weight_sum = np.sum(self.weights)
        if weight_sum > 0:
            self.weights /= weight_sum
        else:
            # Si tous les poids sont proches de zéro, réinitialiser
            self.weights = np.ones(self.num_particles) / self.num_particles
        
        # Resampling adaptatif
        if self.need_resample():
            self.resample()
    
    def need_resample(self):
        """ Détermine si un resampling est nécessaire """
        # Calcul de la taille effective d'échantillon
        if np.sum(self.weights) == 0:
            return True
        neff = 1.0 / np.sum(np.square(self.weights))
        return neff < self.resample_threshold
    
    def resample(self):
        """ Rééchantillonner les particules selon leurs poids """
        indices = np.random.choice(range(self.num_particles), size=self.num_particles, p=self.weights)
        self.particles = [self.particles[i] for i in indices]
        self.weights = np.ones(self.num_particles) / self.num_particles
    
    def get_best_estimate(self):
        """ Renvoyer l'estimation de position basée sur les particules pondérées """
        if np.sum(self.weights) == 0:
            # Si tous les poids sont nuls, utiliser la moyenne simple
            x_mean = np.mean([p[0] for p in self.particles])
            y_mean = np.mean([p[1] for p in self.particles])
            
            # Pour l'angle, utiliser la moyenne circulaire
            cos_sum = np.sum([np.cos(p[2]) for p in self.particles])
            sin_sum = np.sum([np.sin(p[2]) for p in self.particles])
            yaw_mean = np.arctan2(sin_sum, cos_sum)
        else:
            # Utiliser la moyenne pondérée
            x_mean = np.sum([p[0] * w for p, w in zip(self.particles, self.weights)])
            y_mean = np.sum([p[1] * w for p, w in zip(self.particles, self.weights)])
            
            # Moyenne circulaire pondérée pour l'angle
            cos_sum = np.sum([np.cos(p[2]) * w for p, w in zip(self.particles, self.weights)])
            sin_sum = np.sum([np.sin(p[2]) * w for p, w in zip(self.particles, self.weights)])
            yaw_mean = np.arctan2(sin_sum, cos_sum)
            
        return x_mean, y_mean, yaw_mean

class Agent(Node):
    """
    This class is used to define the behavior of ONE agent
    """
    def __init__(self):
        Node.__init__(self, "Agent")
        self.load_params()
        
        #initialize attributes
        self.agents_pose = [None]*self.nb_agents    #[(x_1, y_1), (x_2, y_2), (x_3, y_3)] if there are 3 agents
        self.x = self.y = self.yaw = None   #the pose of this specific agent running the node
        self.prev_x = self.prev_y = self.prev_yaw = None  # Pour calculer le mouvement
        self.lidar_data = None  # Pour stocker les données LIDAR les plus récentes

        self.map_agent_pub = self.create_publisher(OccupancyGrid, f"/{self.ns}/map", 1) #publisher for agent's own map
        self.init_map()
        
        # Initialiser la localisation Monte Carlo après init_map
        self.mcl = MonteCarloLocalization(num_particles=1000, map_size=self.env_size, robot_size=self.robot_size)

        #Subscribe to agents' pose topic
        odom_methods_cb = [self.odom1_cb, self.odom2_cb, self.odom3_cb]
        for i in range(1, self.nb_agents + 1):  
            self.create_subscription(Odometry, f"/bot_{i}/odom", odom_methods_cb[i-1], 1)
        
        if self.nb_agents != 1: #if other agents are involved subscribe to the merged map topic
            self.create_subscription(OccupancyGrid, "/merged_map", self.merged_map_cb, 1)
        
        self.create_subscription(LaserScan, f"{self.ns}/laser/scan", self.lidar_cb, qos_profile=qos_profile_sensor_data) #subscribe to the agent's own LIDAR topic
        self.cmd_vel_pub = self.create_publisher(Twist, f"{self.ns}/cmd_vel", 1)    #publisher to send velocity commands to the robot

        #Create timers to autonomously call the following methods periodically
        self.create_timer(0.2, self.map_update) #0.2s of period <=> 5 Hz
        self.create_timer(0.5, self.strategy)      #0.5s of period <=> 2 Hz
        self.create_timer(1, self.publish_maps) #1Hz
        
        # Variables pour l'exploration
        self.current_target = None
        self.target_reached_threshold = 0.5  # Distance en mètres considérée comme atteinte
        self.get_logger().info("Agent initialized with Monte Carlo Localization")
    

    def load_params(self):
        """ Load parameters from launch file """
        self.declare_parameters(    #A node has to declare ROS parameters before getting their values from launch files
            namespace="",
            parameters=[
                ("ns", rclpy.Parameter.Type.STRING),    #robot's namespace: either 1, 2 or 3
                ("robot_size", rclpy.Parameter.Type.DOUBLE),    #robot's diameter in meter
                ("env_size", rclpy.Parameter.Type.INTEGER_ARRAY),   #environment dimensions (width height)
                ("nb_agents", rclpy.Parameter.Type.INTEGER),    #total number of agents (this agent included) to map the environment
            ]
        )

        #Get launch file parameters related to this node
        self.ns = self.get_parameter("ns").value
        self.robot_size = self.get_parameter("robot_size").value
        self.env_size = self.get_parameter("env_size").value
        self.nb_agents = self.get_parameter("nb_agents").value
    

    def init_map(self):
        """ Initialize the map to share with others if it is bot_1 """
        self.map_msg = OccupancyGrid()
        self.map_msg.header.frame_id = "map"    #set in which reference frame the map will be expressed (DO NOT TOUCH)
        self.map_msg.header.stamp = self.get_clock().now().to_msg() #get the current ROS time to send the msg
        self.map_msg.info.resolution = self.robot_size  #Map cell size corresponds to robot size
        self.map_msg.info.height = int(self.env_size[0]/self.map_msg.info.resolution)   #nb of rows
        self.map_msg.info.width = int(self.env_size[1]/self.map_msg.info.resolution)    #nb of columns
        self.map_msg.info.origin.position.x = -self.env_size[1]/2   #x and y coordinates of the origin in map reference frame
        self.map_msg.info.origin.position.y = -self.env_size[0]/2
        self.map_msg.info.origin.orientation.w = 1.0    #to have a consistent orientation in quaternion: x=0, y=0, z=0, w=1 for no rotation
        self.map = np.ones(shape=(self.map_msg.info.height, self.map_msg.info.width), dtype=np.int8)*UNEXPLORED_SPACE_VALUE #all the cells are unexplored initially
        self.w, self.h = self.map_msg.info.width, self.map_msg.info.height  
    

    def merged_map_cb(self, msg):
        """ 
            Get the current common map and update ours accordingly.
            This method is automatically called whenever a new message is published on the topic /merged_map.
            'msg' is a nav_msgs/msg/OccupancyGrid message.
        """
        received_map = np.flipud(np.array(msg.data).reshape(self.h, self.w))    #convert the received list into a 2D array and reverse rows
        for i in range(self.h):
            for j in range(self.w):
                if (self.map[i, j] == UNEXPLORED_SPACE_VALUE) and (received_map[i, j] != UNEXPLORED_SPACE_VALUE):
                # if received_map[i, j] != UNEXPLORED_SPACE_VALUE:
                    self.map[i, j] = received_map[i, j]


    def odom1_cb(self, msg):
        """ 
            @brief Get agent 1 position.
            This method is automatically called whenever a new message is published on topic /bot_1/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 1:
            # Enregistrer la position précédente pour calculer le déplacement
            if self.x is not None:
                self.prev_x, self.prev_y, self.prev_yaw = self.x, self.y, self.yaw
            
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
            
            # Mise à jour des particules avec le déplacement
            if self.prev_x is not None:
                delta_x = self.x - self.prev_x
                delta_y = self.y - self.prev_y
                delta_yaw = self.normalize_angle(self.yaw - self.prev_yaw)
                
                # Mettre à jour les particules avec le mouvement
                self.mcl.motion_update(delta_x, delta_y, delta_yaw)
        
        self.agents_pose[0] = (x, y)
    

    def odom2_cb(self, msg):
        """ 
            @brief Get agent 2 position.
            This method is automatically called whenever a new message is published on topic /bot_2/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 2:
            # Enregistrer la position précédente pour calculer le déplacement
            if self.x is not None:
                self.prev_x, self.prev_y, self.prev_yaw = self.x, self.y, self.yaw
            
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
            
            # Mise à jour des particules avec le déplacement
            if self.prev_x is not None:
                delta_x = self.x - self.prev_x
                delta_y = self.y - self.prev_y
                delta_yaw = self.normalize_angle(self.yaw - self.prev_yaw)
                
                # Mettre à jour les particules avec le mouvement
                self.mcl.motion_update(delta_x, delta_y, delta_yaw)
        
        self.agents_pose[1] = (x, y)


    def odom3_cb(self, msg):
        """ 
            @brief Get agent 3 position.
            This method is automatically called whenever a new message is published on topic /bot_3/odom.
            
            @param msg This is a nav_msgs/msg/Odometry message.
        """
        x, y = msg.pose.pose.position.x, msg.pose.pose.position.y
        if int(self.ns[-1]) == 3:
            # Enregistrer la position précédente pour calculer le déplacement
            if self.x is not None:
                self.prev_x, self.prev_y, self.prev_yaw = self.x, self.y, self.yaw
            
            self.x, self.y = x, y
            self.yaw = euler_from_quaternion([msg.pose.pose.orientation.x, msg.pose.pose.orientation.y, msg.pose.pose.orientation.z, msg.pose.pose.orientation.w])[2]
            
            # Mise à jour des particules avec le déplacement
            if self.prev_x is not None:
                delta_x = self.x - self.prev_x
                delta_y = self.y - self.prev_y
                delta_yaw = self.normalize_angle(self.yaw - self.prev_yaw)
                
                # Mettre à jour les particules avec le mouvement
                self.mcl.motion_update(delta_x, delta_y, delta_yaw)
        
        self.agents_pose[2] = (x, y)


    def normalize_angle(self, angle):
        """Normalise un angle entre -pi et pi"""
        while angle > np.pi:
            angle -= 2.0 * np.pi
        while angle < -np.pi:
            angle += 2.0 * np.pi
        return angle


    def map_update(self):
        """ Update the occupancy grid with sensor data """
        self.map_msg.data = np.flipud(self.map).flatten().tolist()
    

    def lidar_cb(self, msg):
        """ Process LIDAR data to detect obstacles and update the map. """
        if self.x is None or self.y is None:
            return  # Skip if agent pose is not yet received
        
        # Stocker les données LIDAR pour les utiliser dans la mise à jour MCL
        self.lidar_data = msg
        
        # Mise à jour de l'estimation Monte Carlo
        if self.x is not None and self.y is not None and self.yaw is not None:
            self.mcl.measurement_update(msg, self.map, self.x, self.y, self.yaw, self.map_msg.info)
        
        angles = np.linspace(msg.angle_min, msg.angle_max, len(msg.ranges))
        for angle, distance in zip(angles, msg.ranges):
            if distance < msg.range_max:  # Valid obstacle detection
                # Transform to global coordinates
                obs_x = self.x + distance * np.cos(self.yaw + angle)
                obs_y = self.y + distance * np.sin(self.yaw + angle)
                
                # Convert to grid coordinates
                grid_x = int((obs_x - self.map_msg.info.origin.position.x) / self.map_msg.info.resolution)
                grid_y = self.h - int((obs_y - self.map_msg.info.origin.position.y) / self.map_msg.info.resolution)
                
                # Position du robot dans la grille
                robot_x = int((self.x - self.map_msg.info.origin.position.x) / self.map_msg.info.resolution)
                robot_y = self.h - int((self.y - self.map_msg.info.origin.position.y) / self.map_msg.info.resolution)

                # Tracer une ligne de (robot_x, robot_y) jusqu'à (grid_x, grid_y)
                for free_x, free_y in bresenham(robot_x, robot_y, grid_x, grid_y):
                    if 0 <= free_x < self.w and 0 <= free_y < self.h:
                        self.map[free_y, free_x] = FREE_SPACE_VALUE  # Marquer comme libre

                # Si l'obstacle est dans la grille, le marquer comme occupé
                if 0 <= grid_x < self.w and 0 <= grid_y < self.h:
                    self.map[grid_y, grid_x] = OCCUPIED_SPACE_VALUE  # Marquer comme obstacle


    def publish_maps(self):
        """
            Publish updated map to topic /bot_x/map, where x is either 1, 2 or 3.
            This method is called periodically (1Hz) by a ROS2 timer, as defined in the constructor of the class.
        """
        self.map_msg.data = np.flipud(self.map).flatten().tolist()  #transform the 2D array into a list to publish it
        self.map_agent_pub.publish(self.map_msg)    #publish map to other agents


    def strategy(self):
        """ Decision and action layers """
        if self.x is None or self.y is None:
            return  # Ne rien faire tant que la position n'est pas connue

        # Récupération de la meilleure estimation de la position
        estimated_x, estimated_y, estimated_yaw = self.mcl.get_best_estimate()
        
        # Définir ou vérifier une cible d'exploration
        if self.current_target is None or self.is_target_reached():
            self.current_target = self.find_exploration_target()
            self.get_logger().info(f"New target: ({self.current_target[0]:.2f}, {self.current_target[1]:.2f})")
        
        # Calculer la direction vers la cible
        target_x, target_y = self.current_target
        delta_x, delta_y = target_x - self.x, target_y - self.y
        target_angle = np.arctan2(delta_y, delta_x)
        
        # Différence d'angle à tourner
        angle_diff = self.normalize_angle(target_angle - self.yaw)
        
        # Création des commandes de mouvement
        cmd = Twist()
        
        # Vérifier si un obstacle est devant
        obstacle_front = self.check_obstacle_ahead()
        
        if obstacle_front:
            # En cas d'obstacle, tourner sur place
            cmd.linear.x = 0.0
            cmd.angular.z = 0.5  # Tourner à gauche
            self.get_logger().info("Obstacle ahead, turning...")
            # Réinitialiser la cible pour en trouver une nouvelle
            self.current_target = None
        else:
            # Si l'angle est trop grand, tourner d'abord
            if abs(angle_diff) > 0.3:
                cmd.linear.x = 0.1  # Avancer lentement
                cmd.angular.z = 0.5 if angle_diff > 0 else -0.5
                self.get_logger().info(f"Turning, angle diff: {angle_diff:.2f}")
            else:
                # Sinon, avancer tout en ajustant l'angle
                cmd.linear.x = 2.0
                cmd.angular.z = angle_diff
                self.get_logger().info(f"Moving forward, speed: {cmd.linear.x:.2f}, turn: {cmd.angular.z:.2f}")
        
        # Publier les commandes
        self.cmd_vel_pub.publish(cmd)


    def is_target_reached(self):
        """ Vérifie si la cible actuelle a été atteinte """
        if self.current_target is None:
            return True
            
        target_x, target_y = self.current_target
        distance = np.sqrt((self.x - target_x)**2 + (self.y - target_y)**2)
        return distance < self.target_reached_threshold


    def check_obstacle_ahead(self):
        """ Vérifie s'il y a un obstacle devant le robot """
        if self.lidar_data is None:
            return False
            
        # Vérifier les lectures LIDAR dans un secteur frontal
        front_angle_width = np.pi / 2  # 45 degrés de part et d'autre
        
        angles = np.linspace(self.lidar_data.angle_min, self.lidar_data.angle_max, len(self.lidar_data.ranges))
        for i, angle in enumerate(angles):
            # Ne considérer que les angles dans le secteur frontal
            if abs(angle) < front_angle_width / 2:
                if self.lidar_data.ranges[i] < 1.5:  # Obstacle à moins de 0.5m
                    return True
                    
        return False


    def find_exploration_target(self):
        """ Trouve une cible d'exploration intelligente """
        # Convertir la position du robot en coordonnées de grille
        robot_x = int((self.x - self.map_msg.info.origin.position.x) / self.map_msg.info.resolution)
        robot_y = self.h - int((self.y - self.map_msg.info.origin.position.y) / self.map_msg.info.resolution)
        
        '''
        # Trouver toutes les cellules inexplorées
        unexplored_cells = np.argwhere(self.map == UNEXPLORED_SPACE_VALUE)
        
        if len(unexplored_cells) == 0:
            # Si tout est exploré, trouver une partie moins explorée
            free_cells = np.argwhere(self.map == FREE_SPACE_VALUE)
            if len(free_cells) == 0:
                return self.x, self.y  # Si rien n'est exploré, rester en place
                
            # Choisir une cellule libre aléatoire
            target_idx = np.random.randint(0, len(free_cells))
            y, x = free_cells[target_idx]
        else:
            # Identifier les cellules frontières (proches d'espaces libres)
            frontier_cells = []
            
            for cell in unexplored_cells:
                y, x = cell
                # Vérifier si c'est une cellule frontière (proche d'une zone explorée)
                is_frontier = False
                for dy in [-1, 0, 1]:
                    for dx in [-1, 0, 1]:
                        ny, nx = y + dy, x + dx
                        if (0 <= ny < self.h and 0 <= nx < self.w and 
                            self.map[ny, nx] == FREE_SPACE_VALUE):
                            is_frontier = True
                            break
                    if is_frontier:
                        break
                
                if is_frontier:
                    # Calculer la distance
                    dist = np.sqrt((x - robot_x)**2 + (y - robot_y)**2)
                    # Ne considérer que les frontières pas trop loin
                    if dist < 50:  # Limiter la distance pour éviter de traverser toute la carte
                        frontier_cells.append((dist, x, y))
            
            if not frontier_cells:
                # S'il n'y a pas de frontières proches, prendre une cellule inexplorée aléatoire
                idx = np.random.randint(0, len(unexplored_cells))
                y, x = unexplored_cells[idx]
            else:
                # Prendre une frontière proche, mais pas la plus proche
                # (pour encourager l'exploration)
                frontier_cells.sort()
                if len(frontier_cells) > 5:
                    # Choisir parmi les 5 frontières les plus proches
                    choice_idx = np.random.randint(0, 5)
                    _, x, y = frontier_cells[choice_idx]
                else:
                    _, x, y = frontier_cells[0]
        
        '''
        # Convertir les coordonnées de grille en coordonnées mondiales
        target_x = x * self.map_msg.info.resolution + self.map_msg.info.origin.position.x
        target_y = (self.h - y) * self.map_msg.info.resolution + self.map_msg.info.origin.position.y
        
        return target_x, target_y


def main():
    rclpy.init()

    node = Agent()
    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()
